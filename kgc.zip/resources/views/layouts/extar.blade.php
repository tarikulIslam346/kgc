<section class="_r_sector_wrap" id="about_us">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <img src="img/s4.jpeg" alt="New York" style="width: 100%; height: 450px">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12" style="background-color: green">
                <div style="width: 100%; height: 40px;"></div>
              </div>
            </div>
              <div class="row _r_section_body">
                <div class="col-md-3">
                  <ul>
                    <li class="text-center"><a href="">Committee</a></li>
                    <li class="text-center"><a href="">Committee</a></li>
                    <li class="text-center"><a href="">Committee</a></li>
                    <li class="text-center"><a href="">Committee</a></li>
                  </ul>
                </div>
                <div class="col-md-9 _r_section_body_right">

                  <h1 class="text-center" style="padding-bottom: 30px">Sub Menu Name</h1>

                  <div class="row justify-content-md-center">
                    <div class="col-md-4 _r_top">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                  </div>
                  <div class="row _r_bottom">
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>
