   <!-- slider -->
    <div id="home">
      <div id="demo" class="carousel slide" data-ride="carousel">
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="img/s1.jpeg" alt="Los Angeles">
            </div>
            <div class="carousel-item">
              <img src="img/s2.jpeg" alt="Chicago">
            </div>
            <div class="carousel-item">
              <img src="img/s3.jpeg" alt="New York">
            </div>
             <div class="carousel-item">
              <img src="img/s4.jpeg" alt="New York">
            </div>
          </div>

          <!-- Indicators -->
          <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            <li data-target="#demo" data-slide-to="3"></li>
          </ul>
          
          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
          </a>
      </div>
    </div>
    <!-- slider -->