@extends('layouts.master')

@section('content')
@include('layouts.slider')





@endsection