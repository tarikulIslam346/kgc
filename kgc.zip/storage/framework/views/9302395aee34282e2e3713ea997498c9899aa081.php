<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <!-- Bootstrap CDN s--->
         <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script> 

        <!-- Fontawesome -->
         <link href="https://use.fontawesome.com/releases/v5.0.7/css/all.css" rel="stylesheet">

        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jBox.css">
        
   
    </head>
    <body>
        <div class="main index">
  <div class="main-wrap">
    <header id="_r-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
           <nav id="_r-main-nav">
              <div class="_r-brand-logo">
                  <ul class="_r-brand-logo-wrap _r_ul_deco">
                      <li><a class="_r-main-logo" href="#">Rzs Logo</a></li>
                      <li class="_r-mobile-menu"><i class="fas fa-bars"></i></li>
                      <li class="_r-mobile-menu-cross"><i class="fas fa-times"></i></li>
                  </ul>
              </div>

             <ul class="_r-menu-item _r-left-menu-item _r_ul_deco">
                 <li><a href="#"><br>Home</a></li>
                 <li><a href="#"><br>About Us</a></li>
                 <li><a href="#"><br>Committee</a></li>
             </ul>

             <ul class="_r-menu-item _r-right-menu-item _r_ul_deco">
                 <li><a class="_r-all-wings" href="#"><i class="fas fa-th"></i></a></li>
             </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>

    <!-- slider -->
    <div id="home">
      <div id="demo" class="carousel slide" data-ride="carousel">
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="img/s1.jpeg" alt="Los Angeles">
            </div>
            <div class="carousel-item">
              <img src="img/s2.jpeg" alt="Chicago">
            </div>
            <div class="carousel-item">
              <img src="img/s3.jpeg" alt="New York">
            </div>
             <div class="carousel-item">
              <img src="img/s4.jpeg" alt="New York">
            </div>
          </div>

          <!-- Indicators -->
          <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            <li data-target="#demo" data-slide-to="3"></li>
          </ul>
          
          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
          </a>
      </div>
    </div>
    <!-- slider -->

    <section class="_r_sector_wrap" id="about_us">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <img src="img/s4.jpeg" alt="New York" style="width: 100%; height: 450px">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12" style="background-color: green">
                <div style="width: 100%; height: 40px;"></div>
              </div>
            </div>
              <div class="row _r_section_body">
                <div class="col-md-3">
                  <ul>
                    <li class="text-center"><a href="">Committee</a></li>
                    <li class="text-center"><a href="">Committee</a></li>
                    <li class="text-center"><a href="">Committee</a></li>
                    <li class="text-center"><a href="">Committee</a></li>
                  </ul>
                </div>
                <div class="col-md-9 _r_section_body_right">

                  <h1 class="text-center" style="padding-bottom: 30px">Sub Menu Name</h1>

                  <div class="row justify-content-md-center">
                    <div class="col-md-4 _r_top">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                  </div>
                  <div class="row _r_bottom">
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                    <div class="_r_bottom_row">
                      <img src="img/com.jpeg">
                      <h5 class="text-center">Title</h5>
                      <p class="text-center">Content</p>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>
 </div>
</div>

<script src="js/jquery-3.3.1.js"></script>
<script src="js/jBox.min.js"></script>
<script src="js/script.js"></script>
 
    </body>
</html>
