<?php $__env->startSection('content'); ?>

<!--designe--> 
   <?php if(isset($choices)): ?>
       <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

<section id="_r_speech_form">
    <div class="container-fluid">
      <?php if($choice->choice == "Message"): ?>

                
                 

                  <form action="/heigher/<?php echo e($choice->submenu_id); ?>" method="POST" enctype="multipart/form-data">

                      <?php echo csrf_field(); ?>



                   <div class="row justify-content-md-center">
                       <div class="col-md-2 _r_first_row_deco">
                          <div class="_r_committee_member upload-icon">
                               <img id="singleImageId">
                           </div>
                           <label> Insert Image
                               <input type="file" name="avatar" id="single-file-input" required>
                           </label>
                           <input type="text" name="name" placeholder="Name" class="_r_input_deco" required>
                           <input type="text" name="title" placeholder="Position" class="_r_input_deco" required>
                       </div>
                   </div>
                   <div class="row justify-content-md-center">
                       <div class="col-md-10">
                            <textarea placeholder="Write Your Speech Here" id="message_text" name="description"></textarea>
                       </div>
                   </div>
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>

                      </form>
                   
                  


                  
                   </div> 
                   <?php endif; ?>

                     <?php if($choice->choice == "Image"): ?>

          

                        

                  <form action="/image/<?php echo e($choice->submenu_id); ?>" method="POST" enctype="multipart/form-data">

                      <?php echo csrf_field(); ?>

                         <div class="container-fluid">
                    <div class="row" id="_r_committee_member">
                        <div class="col-md-9 _r_section_body_right">
                            <h1 class="text-center" style="padding-bottom: 30px">Committee Members Image</h1>
                            <div class="row justify-content-md-center">
                                <div class="col-md-4 _r_top">
                                    <div class="_r_wrap_col">
                                        <div class="_r_committee_member upload-icon">
                                        <img id="multiImageId">
                                    </div>
                                    <label> Insert Image
                                        <input type="file" name="filename[]" id="multi-file-input">
                                    </label>
                                    <input type="text" name="name[]" placeholder="Name" class="_r_input_deco">
                                   
                                    </div>
                                </div>
                            </div>
                            <div class="row _r_bottom mytbody"></div>
                            <div class="_r_add_button"><i class="fa fa-plus add_row"></i></div>
                        </div>
                    </div>
                </div>



                      <button type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>
                  
                    
                       
                      </form>








                     
                   
                   <?php endif; ?>
                    <?php if($choice->choice == "Text"): ?>

                
                 

                  <form action="/text/<?php echo e($choice->submenu_id); ?>" method="POST">

                      <?php echo csrf_field(); ?>



             
                   <div class="row justify-content-md-center">
                       <div class="col-md-10">
                            <textarea placeholder="Write Your Speech Here" id="message_text" name="details"></textarea>
                       </div>
                   </div>
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button>

                      </form>
                   
                  


                  
                   </div> 
                   <?php endif; ?>
                      





    </div>
</section>
 
                
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                   <script>
            tinymce.init({ 
                selector:'#message_text',
                  body_class: 'my_class',
                 theme: 'modern',
                    width: 600,
                    height: 300,
                    plugins: [
                      'advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker',
                      'searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking',
                      'save table contextmenu directionality emoticons template paste textcolor'
                    ],
                    content_css: 'css/content.css',
                    toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons'
  
               
              
            });
        </script>

  



 
        

                   
       
             

<!--designe-->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>