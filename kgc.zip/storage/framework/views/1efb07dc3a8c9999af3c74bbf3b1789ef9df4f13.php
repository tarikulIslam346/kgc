<section class="_r_dashboard">
      <div class="_r_dashboard_wrap">
        <div class="container-fluid">
          <div class="row _r_row_wrap">
            <div class="col-md-2 _r_col_wrap">
              <div class="text-center _r_logo">
                <img src="img/logo.png">
              </div>
              <nav class="navbar navbar-expand-lg">
                <button class="navbar-toggler pull-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon bg-light"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="mr-auto">
                    <li id="showmenu">Create Nav Item</li>
                    <li id="showmenu1">Create Sub Nav Item</li>
                    <li id="showmenu2">Create Layout</li>
                    <li id="showmenu3">Create Menu</li>
                  </ul>
                </div>
              </nav>
            </div>
            <div class="col-md-10">
              <div class="row _r_dashboard_right">
                <div class="col-md-12">
                  <div class="menu" style="display: none;">
                    <p>First Div</p>
                  </div>
                  <div class="menu1" style="display: none;">
                    <p>2 Div</p>
                  </div>

                  <div class="menu2" style="display: none;">
                   <p>3 Div</p>
                  </div>

                  <div class="menu3" style="display: none;">
                   <p>4 Div</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>