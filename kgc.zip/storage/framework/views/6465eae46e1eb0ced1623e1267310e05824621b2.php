      
      
  <?php if(session('success')): ?>
                            <div class="alert  alert-success fade show" role="alert">
                               <?php echo e(session('success')); ?> 
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                                  
                           <?php endif; ?>  
<table class="table table-striped table-dark">
         <thead>
           <tr>
             <th>Tournament name</th>
             <th>Update Name</th>
              <th>Winner</th>
              <th>Update Winner Name</th>
              <th>Prize Money</th>
              <th>Update Prize Money</th>
              <th>Schedule Deuration</th>
               <th>Delete</th>
           
           </tr>
         </thead>
       <tbody>


        <?php if(isset($schedules)): ?>
         <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
             <td><?php echo e($schedule->tournament); ?></td>
             <td>
			 	<form method="POST" action="/update_tournament/<?php echo e($schedule->id); ?>">
			                           <?php echo csrf_field(); ?>

                     <div class="row">
                     <div class="col-md-6">
                     <input type="text" class="form-control" name="tournament" id="winner" required>

                   </div>
                   <button type="submit" class="btn btn-success"><i class="fa fa-check"></i></button>
                   </div>
			    </form>
            </td>
            <td><?php echo e($schedule->winner); ?></td>
             <td>
			 	<form method="POST" action="/update_winner/<?php echo e($schedule->id); ?>">
			                           <?php echo csrf_field(); ?>

                     <div class="row">
                     <div class="col-md-6">
                     <input type="text" class="form-control" name="winner" id="winner" required>

                   </div>
                   <button type="submit" class="btn btn-success"><i class="fa fa-check"></i></button>
                   </div>
			    </form>
            </td>
            <td><?php echo e($schedule->prize_money); ?>  BDT </td>
            <td>
        	<form method="POST" action="/update_prize/<?php echo e($schedule->id); ?>">
		                           <?php echo csrf_field(); ?>

                 <div class="row">
                 <div class="col-md-6">
                 <input type="text" class="form-control" name="prize_money" id="prize_money" required>

               </div>
               <button type="submit" class="btn btn-success"><i class="fa fa-check"></i></button>
               </div>
		    </form>
            </td>
            <td><?php echo e(\Carbon\Carbon::parse($schedule->start_date)->format('F d ')); ?> - 
              <?php echo e(\Carbon\Carbon::parse($schedule->closing_date )->format('F d ')); ?> </td>

               <td>
                   <a href="/delete_schedule/<?php echo e($schedule->id); ?>" class="btn btn-danger"><i class="fa fa-minus-square"></i>
                               </a>
                             </td>
            
           </tr>
             

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               
           <?php endif; ?>
         </tbody>
       </table>


         <?php if($errors->has('name')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <p><?php echo e($errors->first('name')); ?> </p>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     <?php endif; ?>
