  <header id="_r-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
           <nav id="_r-main-nav">
              <div class="_r-brand-logo">
                  <ul class="_r-brand-logo-wrap _r_ul_deco">
                      <li><a class="_r-main-logo" href="#">Rzs Logo</a></li>
                      <li class="_r-mobile-menu"><i class="fas fa-bars"></i></li>
                      <li class="_r-mobile-menu-cross"><i class="fas fa-times"></i></li>
                  </ul>
              </div>

             <ul class="_r-menu-item _r-left-menu-item _r_ul_deco">
                 <li><a href="/" style="font-size: 12px;font-family: 'Comfortaa', cursive;">
                  <br><?php echo e(strtoupper('Home')); ?></a></li>
                 <li><a href="/schedule" style="font-size: 12px;font-family: 'Comfortaa', cursive;">
                  <br><?php echo e(strtoupper('schedule')); ?></a></li>

                 <?php
                   $count = 0;

                 ?>

                 <?php if(isset($menus)): ?>

                 <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($count == 4): ?>
                    <?php break; ?>

                  <?php endif; ?>
                   <li><a href="/nav/<?php echo e($menu->id); ?>/<?php echo e($menu->name); ?>" style="font-size: 12px;font-family: 'Comfortaa', cursive;">
                    <br><?php echo e(strtoupper($menu->name)); ?></a></li>
                  

                
                  <?php
                    $count++;
                  ?>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>

               
                 
             </ul>
             
            <ul class="_r-menu-item _r-right-menu-item _r_ul_deco">


                <li id="_r_extra_menu_show"><a class="_r-all-wings" href="#" ><i class="fas fa-th"></i></a></li>
                 <div class="_r_extra_menu" style="display: none;">

                  
                    <?php if(isset($menus)): ?>

                   <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($count >=5): ?> <?php continue; ?>   <?php endif; ?>
                   
                    <li><?php echo e(strtoupper($menu->name)); ?></li>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                
                    
                </div>
             </ul>
             <?php if(\Auth::check()): ?>
             <ul style="margin: auto;">
                 <li style="color:#fff;"><a href="/dashboard" ><?php echo e(strtoupper(\Auth::user()->name)); ?></a>
                 <a href="/destroy" type="button" class="btn btn-success"><i class="fa fa-ship"></i>Logout</a>
                 </li>
             </ul>
             <?php endif; ?>

            </nav>
          </div>
        </div>
      </div>
    </header>