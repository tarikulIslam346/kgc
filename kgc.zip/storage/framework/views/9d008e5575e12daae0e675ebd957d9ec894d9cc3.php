<?php $__env->startSection('content'); ?>


  <div class="container box">
   
   <div class="panel panel-default">
    <div class="panel-heading">Find Tournament</div>
    <div class="panel-body">
     <div class="input-group mb-3">
       <div class="input-group-prepend">
        <input class="form-control" type="date"/>
      <input type="text" name="search"  id="text" class="form-control" placeholder="Search Customer Data" />
      <button id="search" class="btn btn-primary"><i class="fa fa-search"></i>Search</button>
    </div>
     </div>

    
      

    
    <div class="row">
      <div class="col-sm">
        Date
      </div>
      <div class="col-sm">
        Touranment
      </div>
      <div class="col-sm">
        Prize Money
      </div>
      <div class="col-sm">
        Winner
      </div>
    </div>
    <div  id="list">
    </div>



    </div>    
   </div>
  </div>


<script>
$(document).ready(function(){
 fetch_customer_data();
 function fetch_customer_data(query = '')
 {
  $.ajax({
   url:"/schedule_search",
   method:'GET',
   data:{query:query},
   dataType:'json',
   success:function(data)
   {
    $('#list').html(data.table_data);
    // $('#total_records').text(data.total_data);
   }
  })
 }
 $(document).on('click', '#search', function(){
  var query = $('#text').val();
  fetch_customer_data(query);
 });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>