                    <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php 
                   $var = \App\Submenu::select('name')->where('id',$submenu->id)->get();

                 
                    ?>
                     <form class="form-inline" action="/heigher/<?php echo e($submenu->id); ?>" method="post">

                     	<?php echo csrf_field(); ?>
                        <label class="sr-only" for="inlineFormInputName2">Heading</label>
                        <input type="text" class="form-control mb-2 mr-sm-2" 
                        id="inlineFormInputName2" placeholder="Jane Doe" name="heading">

                        <label class="sr-only" for="inlineFormInputGroupUsername2">Username</label>
                        <div class="input-group mb-2 mr-sm-2">
                          <div class="input-group-prepend">
                            <div class="input-group-text">Paragraph</div>
                          </div>
                          <input type="text" class="form-control" id="inlineFormInputGroupUsername2" 
                          placeholder="Username" name="paragraph">
                        </div>

                        

                        <button type="submit" class="btn btn-primary mb-2" value>Submit</button>
                         <?php $__currentLoopData = $var; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($v->name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </form>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>