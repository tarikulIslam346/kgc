<?php $__env->startSection('content'); ?>

 <?php if(isset($schedulename)): ?>
         <?php $__currentLoopData = $schedulename; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


 				<h3><?php echo e($schedule->tournament); ?></h3>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               
           <?php endif; ?>
      <hr>


<table class="table table-striped table-dark">
         <thead>
           <tr>
             <th>Pos</th>
             
              <th>Name</th>
             
              <th>To PAR</th>
              <th>HOLE</th>

              <th>TODAY</th>
              <th>R1</th>
              <th>R2</th>
              <th>R3</th>
              <th>R4</th>
              <th>Total</th>
              <th>Earnings</th>
              <th>HFH RANKING</th>
             

           
           </tr>
         </thead>
       <tbody>


        <?php if(isset($scheduleDetails)): ?>
         <?php $__currentLoopData = $scheduleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scheduleDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
             <td><?php echo e($scheduleDetail->pos); ?></td>
             
		
        
            <td><?php echo e($scheduleDetail->name); ?></td>
             
		
           
            <td><?php echo e($scheduleDetail->to_par); ?>  </td>
            
 
           
             <td><?php echo e($scheduleDetail->hole); ?>  </td>
              <td><?php echo e($scheduleDetail->today); ?>  </td>
            <td><?php echo e($scheduleDetail->r1); ?>  </td>
             <td><?php echo e($scheduleDetail->r2); ?>  </td>
             <td><?php echo e($scheduleDetail->r3); ?>  </td>
              <td><?php echo e($scheduleDetail->r4); ?>  </td>
              <td><?php echo e($scheduleDetail->r1 +$scheduleDetail->r2+$scheduleDetail->r3+$scheduleDetail->r4); ?></td>
              <td><?php echo e($scheduleDetail->earnings); ?>  </td>
              <?php if($scheduleDetail->hfh_ranking == null || $scheduleDetail->hfh_ranking == 0): ?>
              <td> ----- </td>
              <?php else: ?> <td> <?php echo e($scheduleDetail->hfh_ranking); ?> </td>
              <?php endif; ?>
              
            
            
           </tr>
             

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               
           <?php endif; ?>
         </tbody>
       </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>