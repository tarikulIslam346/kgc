          <ul>
              
                    <?php if(isset($menu)): ?>
                    
                    <?php $__currentLoopData = $menu->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                     
                      

                      <li class="text-center">

                        <a href="/navigation/<?php echo e($submenu->name); ?>/<?php echo e($submenu->id); ?>/<?php echo e($menu->id); ?>" id="loadcontent">

                          <?php echo e($submenu->name); ?>

                          
                        </a>

                      </li>

             

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      <?php endif; ?>

</ul>