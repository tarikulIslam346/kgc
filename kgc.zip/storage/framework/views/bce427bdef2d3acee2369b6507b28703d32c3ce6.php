<?php if(session('success')): ?>
                            <div class="alert  alert-success fade show" role="alert">
                               <?php echo e(session('success')); ?> 
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                                  
                           <?php endif; ?>

                      <form action="/create_submenu" method="POST">
                       <?php echo csrf_field(); ?>
                         <div class="input-group mb-3">
                           <div class="input-group-prepend">
                               <span class="input-group-text">Add Submenu title here</span>
                           </div>

                           <input type="text" class="form-control" name="name" placeholder="Title">

                           <button type="submit" class="btn btn-success"><i class="fa fa-plus"></i></button>
                         </div>
                       </form>

                          <?php if($errors->has('name')): ?>
                              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                              <p><?php echo e($errors->first('name')); ?> </p>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                           <?php endif; ?>
                       <table class="table table-striped table-dark">
                         <thead>
                           <tr>
                             <th>Navigation Subitem name</th>

                             <!--  -->
                             <th>Edit Navigation Subitem name</th>

                            

                             <th>Delete</th>
                              <th> Selected Layout</th>
                            
                           </tr>
                         </thead>
                       <tbody>
                        <?php if(isset($submenus)): ?>
                         <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                             <td><?php echo e($submenu->name); ?></td>


                              <td>
                                 <form method="POST" action="/update_submenu/ <?php echo e($submenu->id); ?>">
                                       <?php echo csrf_field(); ?>
                                     <div class="row">
                                       <div class="col-md-6">
                                         <input type="text" class="form-control" name="name" id="name" required>
                                       </div>
                                       <button type="submit" class="btn btn-success"><i class="fa fa-edit"></i></button>
                                     </div>
                                   </form>
                               </td>

                            <td>
                               <a href="/delete_submenu/<?php echo e($submenu->id); ?>" class="btn btn-danger"><i class="fa fa-minus-square"></i>
                               </a>
                             </td>
                                <?php
                                  $var =  \App\LayoutChoice::select('choice')
                                            ->where('submenu_id',$submenu->id )->get();
                                 ?>
                                 <?php $__currentLoopData = $var; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <td>
                                 <!-- selected layout goes here-->
                                 <?php echo e($v->choice); ?>

                                
                               </td>

                            
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>
                         </tbody>
</table>