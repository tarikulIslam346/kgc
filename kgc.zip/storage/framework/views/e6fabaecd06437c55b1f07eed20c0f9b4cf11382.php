                      <?php if(session('success')): ?>
                            <div class="alert  alert-success fade show" role="alert">
                               <?php echo e(session('success')); ?> 
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                                  
                           <?php endif; ?>

                      <form action="/create_notice" method="POST">
                       <?php echo csrf_field(); ?>
                         <div class="form-group">
                           
                               <label for="notice">Add Notice here</span>
                          

                           <textarea placeholder="Write Your Speech Here" id="notice_text" name="notice" class="form-control">
                             
                           </textarea>
                            </div>

                           <button type="submit" class="btn btn-success"><i class="fa fa-plus"></i></button><br>
                         
                       </form>

                          <?php if($errors->has('name')): ?>
                              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                              <p><?php echo e($errors->first('name')); ?> </p>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                           <?php endif; ?>
                       <table class="table table-striped table-dark">
                         <thead>
                           <tr>
                             <th>Notice</th>

                             <!--  -->
                            

                            

                             <th>Delete</th>
                             
                            
                           </tr>
                         </thead>
                       <tbody>
                          <?php if(isset($notices)): ?>
                         <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo $notice->notice; ?></td>
                            <td><a href="/delete_notice/<?php echo e($notice->id); ?>" class="btn btn-danger"><i class="fa fa-minus-square"></i></td>
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                      
                         </tbody>
                        
                      </table>


        <script>
            tinymce.init({ 
                selector:'#notice_text'
  
              
            });
        </script>