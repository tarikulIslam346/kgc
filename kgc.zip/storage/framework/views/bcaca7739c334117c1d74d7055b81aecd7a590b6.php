<?php $__env->startSection('content'); ?>

<section class="_r_sector_wrap" id="about_us">


  
        
          <img src="/img/s4.jpeg" alt="New York" style="width: 100%; height: 450px">
        
      



      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12" style="padding: 0">
                <div id="wrapper">
                  <div class="first">
                    <dl id="ticker-1">
                      <?php if(isset($notices)): ?>
                      <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <dt><?php echo e(\Carbon\Carbon::parse($notice->created_at)->format('F d ')); ?></dt>
                        <dd><?php echo $notice->notice; ?></dd>
                  
                    
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
            <div class="row _r_section_body">
              <div class="col-md-3" style="background-color: gray">
                <?php echo $__env->make('pagenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>

                <div class="col-md-9 _r_section_speech_body_right">

                   <?php if(isset($h)): ?>
                           <?php $__currentLoopData = $h; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          
                 
                        <div class=" _r_section_body_right">

                                    
                                    <div class="row justify-content-md-center">

                                        <div class="col-md-4 _r_top">
                                            <img src="<?php echo e(Storage::url( $hf->heading )); ?>"/>
                                            <h5 class="text-center"><?php echo e($hf->name); ?></h5>
                                            
                                        </div>
                                        <div class="col-md-12 _r_top">
                                            <p class="text-center">
                                              <?php echo $hf->description; ?>;


                                            </p> 
                                        </div>
                                    </div>
                                </div>
                           
                          
                        
                      </div>
                  </div>
                
         
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                 
  

                   <?php if(isset($image)): ?>
                           <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          
                 
                        <div class=" _r_section_body_right">

                                    
                                    <div class="row justify-content-md-center">

                                        <div class="col-md-4 _r_top">
                                            <img src="/images/<?php echo e($img->img_url[0]); ?>"/>
                                            <h5 class="text-center"><?php echo e($img->name[0]); ?></h5>
                                            
                                        </div>
                                    </div>
                                   
                                   
                                   
                                    
                                    <div class="row _r_bottom">
                                        <?php for($i=1 ; $i< count($img->img_url); $i++): ?>
                                     
                                      
                                        <div class="col-md-4">
                                          
                                            <img src="/images/<?php echo e($img->img_url[$i]); ?>"/>
                                            <h5 class="text-center"><?php echo e($img->name[$i]); ?></h5>
                                            <p class="text-center">Content</p>
                                            
                                        </div>
                                         <?php endfor; ?>
                                          
                               
                                        
                                    </div>
                                    
                                </div>

                        
                         
                      
                           
                             
                              
                            
                            
                          
                          
                        
                      </div>
                  </div>
                
               
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                  <?php if(isset($text)): ?>
                           <?php $__currentLoopData = $text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          
                 
                        <div class=" _r_section_body_right">

                                    
                                    <div class="row justify-content-md-center">

                                       
                                        <div class="col-md-12 _r_top">
                                            <p class="text-center">
                                              <?php echo $page->details; ?>;


                                            </p> 
                                        </div>
                                    </div>
                                </div>
                           
                          
                        
                      </div>
                  </div>
                
         
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </div>


         
            </div>
          </div>
        </div>
      </div>
    </section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>