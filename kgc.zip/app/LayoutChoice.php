<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LayoutChoice extends Model
{
    //
    protected $fillable = ['choice','submenu_id'];
}
