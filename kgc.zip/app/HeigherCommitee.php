<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeigherCommitee extends Model
{
    //
    protected $fillbale= ['heading','name','title','description','submenu_id'];

    // protected $casts = [

    // 	'heading' => 'array'
    // ];
}
